<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// // Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
// //     return $request->user();
// // });

// // Route::get('auth/google', 'AuthController@redirectToGoogle');
// // Route::get('auth/google/callback', 'AuthController@handleGoogleCallback');
// // Route::get('auth/facebook', 'AuthController@redirectToFacebook');
// // Route::get('auth/facebook/callback', 'AuthController@handleFacebookCallback');

// // Route::post('login/google', 'SocialAuthController@handleGoogleCallback');
// // Route::post('login/facebook', 'SocialAuthController@handle

// Route::get('auth/google', 'SocialAuthController@redirectToGoogle');
// Route::get('auth/google/callback', 'SocialAuthController@handleGoogleCallback');
// Route::get('auth/facebook', 'SocialAuthController@redirectToFacebook');
// Route::get('auth/facebook/callback', 'SocialAuthController@handleFacebookCallback');


// Forgot password
// Route::post('forgot-password', 'App\Http\Controllers\Auth\ForgotPasswordController@forgotPassword');
// Route::post('reset-password', 'App\Http\Controllers\Auth\ResetPasswordController@resetPassword');

// Route::post('sendPasswordResetLink', 'Auth\ForgotPasswordController@sendResetLinkEmail');
// Route::post('resetPassword', 'Auth\ResetPasswordController@reset');

// Route::group(['middleware' => ['auth:api']], function () {
    Route::get('/user/{user_id}', 'App\Http\Controllers\AuthController@getUser');
    Route::post('/getSurveys', 'App\Http\Controllers\SurveyController@index');
    Route::post('/getSkills', 'App\Http\Controllers\SurveyController@getSkills');
// });

Route::post('review', 'App\Http\Controllers\ReviewController@addReview');
Route::post('getReviews', 'App\Http\Controllers\ReviewController@index');

Route::post('addSchedule', 'App\Http\Controllers\ScheduleController@addSchedule');
Route::post('getTodaySchedules', 'App\Http\Controllers\ScheduleController@getTodaySchedules');
Route::post('getSchedules', 'App\Http\Controllers\ScheduleController@index');

Route::post('auth/register', 'App\Http\Controllers\AuthController@register');
Route::post('social/register', 'App\Http\Controllers\AuthController@socialRegister');
Route::post('auth/login', 'App\Http\Controllers\AuthController@login');
Route::post('updateUser', 'App\Http\Controllers\AuthController@updateUser');

Route::post('auth/send', 'App\Http\Controllers\VerificationController@send');
Route::post('auth/verify', 'App\Http\Controllers\VerificationController@verify');

Route::post('verifyForgotCode', 'App\Http\Controllers\ForgotPasswordController@verifyForgotCode');
Route::post('sendPasswordResetCode', 'App\Http\Controllers\ForgotPasswordController@sendResetLinkEmail');
Route::post('updatePassword', 'App\Http\Controllers\ForgotPasswordController@updatePassword');



// Route::post('resetPassword', 'Auth\ResetPasswordController@reset');


Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    // return what you want
});
