<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class VerifyEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $verificationCode;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($verificationCode)
    {
        // Generate a 6-digit verification code
        $this->verificationCode = $verificationCode;
        // $this->verificationCode = rand(100000, 999999);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
{
    return $this->subject(config('app.name') . ' - Verify Your Email Address')
                // ->view('emails.verifyemail')
                ->html("
                Hello!
                    <p>Your verification code is: ". $this->verificationCode ."</p>

                    <p>Please use this code to verify your email address.</p>

                    <p>Thank you,</p>
                ")
                ->with(['verificationCode' => $this->verificationCode]);
}

}
