<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Skill extends Model
{
    use HasFactory;
    protected $table = 'skills';
    protected $fillable = ['id', 'title', 'submitted_by', 'video_url','image_url','description'];
    
    public function user() {
        return $this->belongsTo(\App\Models\User::class, 'submitted_by', 'id');
    }
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public function surveys()
    {
        return $this->hasMany(\App\Survey::class, 'skill_id', 'id');
    }

}
