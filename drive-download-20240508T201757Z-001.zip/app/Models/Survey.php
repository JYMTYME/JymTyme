<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Survey extends Model
{
    use HasFactory;
    protected $table = 'surveys';
    protected $fillable = ['id', 'title', 'submitted_by', 'description', 'skill_id','duration','calories'];
    
    public function user() {
        return $this->belongsTo(\App\Models\User::class, 'submitted_by', 'id');
    }
    public function skill() {
        return $this->belongsTo(\App\Models\Skill::class, 'skill_id', 'id');
    }

}

