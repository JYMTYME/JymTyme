<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Carbon\Carbon;

class Schedule extends Model
{
    use HasFactory;
    protected $table = 'schedules';
    protected $fillable = ['id', 'title', 'submitted_by', 'description', 'schedule_date', 'start_time', 'end_time', 'schedule_start_time', 'schedule_end_time'
    , 'street_address_1'
    , 'street_address_10'
    , 'city'
    , 'state'
    , 'zipcode'
    , 'country'
    , 'lati'
    , 'longi'
];
    
    public function user() {
        return $this->belongsTo(\App\Models\User::class, 'submitted_by', 'id');
    }

    

    public static function boot()
    {
        parent::boot();

        static::creating(function ($data) {
            // before create() method call this
            $data->schedule_start_time = Carbon::parse($data->schedule_date . ' ' . $data->start_time);//->format("Y-m-d H:i:s");
            $data->schedule_end_time = Carbon::parse($data->schedule_date . ' ' . $data->end_time);//->format("Y-m-d H:i:s");
        });

        static::updating(function ($data) {
            // before update() method call this
            $data->schedule_start_time = Carbon::parse($data->schedule_date . ' ' . $data->start_time);//->format("Y-m-d H:i:s");
            $data->schedule_end_time = Carbon::parse($data->schedule_date . ' ' . $data->end_time);//->format("Y-m-d H:i:s");
        });
    }
    

    
    public function getStartTimeAttribute($value)
    {
        if(!empty($value)) {
            $time = Carbon::createFromFormat('H:i:s', $value);
            $value = $time->format('g:i A');
        }
        return $value;
    }
    
    public function getEndTimeAttribute($value)
    {
        if(!empty($value)) {
            $time = Carbon::createFromFormat('H:i:s', $value);
            $value = $time->format('g:i A');
        }
        return $value;
    }
}
