<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'verified',
        'verification_code',
        'forgot_verification_code',
        'forgot_verified',
        'password',
        'provider',
        'device_type',
        'device_id',
        'device_token',
        // 'email_verified_at',
        'provider_id',
        'biography',
        'user_type',
        'profile_image',
        'lati',
        'longi',
        'phone',
        "google_login",
        "google_token",
        "fb_login",
        "fb_token",
        "gender",
        "device_model",
        "api_token",
        "device_os"
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'verification_code',
        'forgot_verification_code',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public function reviews()
    {
        return $this->hasMany(\App\Review::class, 'submitted_by', 'id');
    }
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public function skills()
    {
        return $this->hasMany(\App\Skill::class, 'submitted_by', 'id');
    }
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    public function surveys()
    {
        return $this->hasMany(\App\Survey::class, 'submitted_by', 'id');
    }

    public function getProfileImageAttribute($value)
    {
        if(!empty($value)) {
            $value = url('/public/' . $value);
        }
        return $value;
    }


}
