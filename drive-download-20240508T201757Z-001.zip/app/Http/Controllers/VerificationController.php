<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyEmail;
use Illuminate\Support\Facades\Validator;

use App\Models\User;

class VerificationController extends Controller
{
    public function send(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['message' => 'User not found']);
        }

        if ($user->verified) {
            return response()->json(['message' => 'Account already verified']);
        }

        $verificationCode = mt_rand(100000, 999999);

        $user->verification_code = $verificationCode;
        $user->save();

        // Send email or SMS with code here
        
        // Send the verification code to the user via email
        Mail::to($user->email)->send(new VerifyEmail($verificationCode));

        return response()->json(['message' => 'Verification code sent']);
    }

    public function verify(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
            'verification_code' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user = User::where('email', $request->email)
                    ->where('verification_code', $request->verification_code)
                    ->first();

        if (!$user) {
            return response()->json(['error' => 'Invalid verification code'], 404);
            // return response()->json(['message' => 'Invalid verification code']);
        }

        $user->verified = true;
        $user->verification_code = null;
        $user->save();

        return response()->json(['message' => 'Account verified']);
    }
}
