<?php

namespace App\Http\Controllers;

use App\Models\Skill;
use App\Models\Survey;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SurveyController extends Controller
{
    
    public function addSurvey(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'user_id' => 'required|exists:users,id'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        
        $user_id = $request->input('user_id', null);
        $title = $request->input('title', null);
        $description = $request->input('description', null);

        $item = $request->all();
        $item['submitted_by'] = $user_id;
        $item['title'] = $title;
        $item['description'] = $description;
        // Save the review for the user's record in the database
        $Survey = Survey::create($item);

        return response()->json(['message' => 'Survey successfully submitted', 'survey' => $Survey]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $sortBy = null;
        $orderBy = null;
        $filter = $request->get('filter', null);
        $pageSize = $request->get('pageSize', null);
        $user_id = $request->get('user_id', null);
        $skill_id = $request->get('skill_id', null);
        $sortByString = $request->get('sort', null)?:'id,desc:false';
        if ($sortByString){
            $sortByStringExp =  explode(',', $sortByString);
            $sortBy = $sortByStringExp[0];
            $orderByString = explode(':', $sortByStringExp[1]);
            $orderBy = $orderByString[1] == 'true' ? 'asc':'desc';
        }

        $data =  Survey::with(['user', 'skill'])
        ->when($user_id,function($q) use ($user_id){
            $q->where('submitted_by',$user_id);
        })
        ->when($skill_id,function($q) use ($skill_id){
            $q->where('skill_id',$skill_id);
        })
        ->when($filter,function($q) use ($filter){
            $q->where(function($q) use ($filter){
                $q->where('id','like', '%' . $filter . '%')
                    ->orWhere('title','like', '%' . $filter . '%')
                    ->orWhere('description','like', '%' . $filter . '%')
                    ->orWhere('duration','like', '%' . $filter . '%')
                    ->orWhere('calories','like', '%' . $filter . '%');
            });
        })
        ->when($sortBy || $orderBy, function($query) use ($sortBy, $orderBy){
            $query->orderBy($sortBy, $orderBy);
        })
        ->paginate(20);
        return response()->json(['data' => $data]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getSkills(Request $request)
    {
        $sortBy = null;
        $orderBy = null;
        $filter = $request->get('filter', null);
        $pageSize = $request->get('pageSize', null);
        $user_id = $request->get('user_id', null);
        $skill_id = $request->get('skill_id', null);
        $sortByString = $request->get('sort', null)?:'id,desc:false';
        if ($sortByString){
            $sortByStringExp =  explode(',', $sortByString);
            $sortBy = $sortByStringExp[0];
            $orderByString = explode(':', $sortByStringExp[1]);
            $orderBy = $orderByString[1] == 'true' ? 'asc':'desc';
        }

        $data =  Skill::with(['user'])
        ->when($user_id,function($q) use ($user_id){
            $q->where('submitted_by',$user_id);
        })
        ->when($skill_id,function($q) use ($skill_id){
            $q->where('id',$skill_id);
        })
        ->when($filter,function($q) use ($filter){
            $q->where(function($q) use ($filter){
                $q->where('id','like', '%' . $filter . '%')
                    ->orWhere('title','like', '%' . $filter . '%')
                    ->orWhere('description','like', '%' . $filter . '%');
            });
        })
        ->when($sortBy || $orderBy, function($query) use ($sortBy, $orderBy){
            $query->orderBy($sortBy, $orderBy);
        })
        ->paginate(20);
        return response()->json(['data' => $data]);
    }
}
