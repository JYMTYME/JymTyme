<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\VerifyEmail;
use App\Models\User;
// use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

// use Illuminate\Support\Facades\Password;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    // use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function validateEmail($request)
    {
        $request->validate(['email' => 'required']);
    }

    /**
     * Get the needed authentication credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request)
    {
        return $request->only('email');
    }

    public function sendResetLinkEmail(Request $request)
    {
        $this->validateEmail($request);

        // We will send the password reset link to this user. Once we have attempted
        // to send the link, we will examine the response then see the message we
        // need to show to the user. Finally, we'll send out a proper response.
        $user = User::where('email',$request->email)->where('verified', 1)->first();
        // $request['email'] = $user->email;.
        if($user){

            // Generate a 6-digit verification code
            $verificationCode = rand(100000, 999999);
            $user->fill(['forgot_verification_code' => $verificationCode,
            'forgot_verified' => false]);
            $user->save();

            // Send the verification code to the user via email
            Mail::to($user->email)->send(new VerifyEmail($verificationCode));

            return response()->json(['status'=>'success', 'message'=>'Verification code generated successfully, please check your email.', 'email' => $user->email]);
            
            // $response = $this->broker()->sendResetLink(
            //     $this->credentials($request)
            // );
        }else{
            return response([
                'status' => 'error',
                'error' => 'You have entered invalid email or password!',
                'msg' => 'Invalid Credentials.'
            ], 400);
        }

        // return $response == Password::RESET_LINK_SENT
        //     ? response()->json(trans($response))
        //     : response()->json(trans($response));
    }

    public function verifyForgotCode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
            'forgot_verification_code' => 'required|exists:users',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user = User::where('email', $request->email)
                    ->where('forgot_verification_code', $request->forgot_verification_code)
                    ->first();

        if (!$user) {
            return response()->json(['error' => 'Invalid verification code'], 404);
        }

        $user->forgot_verified = true;
        $user->forgot_verification_code = null;
        $user->save();

        return response()->json(['status'=>'success', 'message' => 'Forgot code verified']);
    }

    
    public function updatePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users',
            'password' => 'required|confirmed|min:3'
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user = User::where('email', $request->email)
            ->where('forgot_verified', true)
                    ->first();

        if (!$user) {
            return response()->json(['error' => 'Invalid request'], 404);
        }

        $passwd = bcrypt($request->input('password'));
        $user->update(['password' => $passwd, 'forgot_verified' => false]);
        // $user->save();

        return response()->json(['status'=>'success', 'message' => 'Password updated successfully!']);
    }
    
}
