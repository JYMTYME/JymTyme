<?php

namespace App\Http\Controllers;

use App\Models\Schedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ScheduleController extends Controller
{
    public function addSchedule(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'user_id' => 'required|exists:users,id',
            'schedule_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        
        $user_id = $request->input('user_id', null);
        $title = $request->input('title', null);
        $description = $request->input('description', null);
        $schedule_date = $request->input('schedule_date', null);
        $start_time = $request->input('start_time', null);
        $end_time = $request->input('end_time', null);

        
        $start_time = date("H:i:s", strtotime($start_time));;
        $end_time = date("H:i:s", strtotime($end_time));;


        // $schedule_start_time = $schedule_date . ' ' . $start_time;
        // $schedule_end_time = $schedule_date . ' ' . $end_time;

        $item = [];
        $item['submitted_by'] = $user_id;
        $item['title'] = $title;
        $item['description'] = $description;
        $item['schedule_date'] = $schedule_date;
        $item['start_time'] = $start_time;
        $item['end_time'] = $end_time;

        $street_address_1 = $request->input('street_address_1', null);
        if($street_address_1) {
            $item['street_address_1'] = $street_address_1;
        }
        
        $street_address_2 = $request->input('street_address_2', null);
        if($street_address_2) {
            $item['street_address_2'] = $street_address_2;
        }
        
        $city = $request->input('city', null);
        if($city) {
            $item['city'] = $city;
        }
        
        $state = $request->input('state', null);
        if($state) {
            $item['state'] = $state;
        }       
        
        $zipcode = $request->input('zipcode', null);
        if($zipcode) {
            $item['zipcode'] = $zipcode;
        }       
        
        $country = $request->input('country', null);
        if($country) {
            $item['country'] = $country;
        }
        
        $lati = $request->input('lati', null);
        if($lati) {
            $item['lati'] = $lati;
        }
        
        $longi = $request->input('longi', null);
        if($longi) {
            $item['longi'] = $longi;
        }
        
        //return $item;

        // $item['schedule_start_time'] = $schedule_start_time;
        // $item['schedule_end_time'] = $schedule_end_time;
        // Save the schedule for the user's record in the database
        $data = Schedule::create($item);
        $data = Schedule::with(['user'])->find($data->id);

        return response()->json(['message' => 'record successfully submitted', 'data' => $data]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $day = null)
    {
        $sortBy = null;
        $orderBy = null;
        $filter = $request->get('filter', null);
        $pageSize = $request->get('pageSize', null);
        $user_id = $request->get('user_id', null);
        $schedule_date = $request->get('schedule_date', null);
        $sortByString = $request->get('sort', null)?:'id,desc:false';
        if ($sortByString){
            $sortByStringExp =  explode(',', $sortByString);
            $sortBy = $sortByStringExp[0];
            $orderByString = explode(':', $sortByStringExp[1]);
            $orderBy = $orderByString[1] == 'true' ? 'asc':'desc';
        }

        $data =  Schedule::with(['user'])
        ->when($user_id,function($q) use ($user_id){
            $q->where('submitted_by',$user_id);
        })
        ->when($filter,function($q) use ($filter){
            
            $q->where(function($q) use ($filter){
                $q->where('id','like', '%' . $filter . '%')
                    ->orWhere('title','like', '%' . $filter . '%')
                    ->orWhere('description','like', '%' . $filter . '%');
            });
            
        })
        ->when(($day && $day == 'today'),function($q) use ($filter){
            $q->where(function($q) use ($filter){
                $q->whereDate('schedule_start_time', '>=', today())
                ->whereDate('schedule_end_time', '<=', today());
            });
            
        })
        ->when(($schedule_date),function($q) use ($schedule_date){
            $q->where(function($q) use ($schedule_date){
                $q->whereDate('schedule_start_time', '>=', $schedule_date)
                ->whereDate('schedule_end_time', '<=', $schedule_date);
            });
            
        })
        ->when($sortBy || $orderBy, function($query) use ($sortBy, $orderBy){
            $query->orderBy($sortBy, $orderBy);
        })
        ->paginate(20);

        return response()->json(['schedules' => $data]);
        return $this->sendSuccessResponse('data', ['pagination' => $data], 'Templates retrieved successfully!');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getTodaySchedules(Request $request)
    {
        return $this->index($request, 'today');
    }

}
