<?php

namespace App\Http\Controllers;

use App\Mail\VerifyEmail;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Str;


class AuthController extends Controller
{

    public function getUser($user_id, Request $request)
    {
        $validator = Validator::make(['user_id' => $user_id], [
            'user_id' => 'required|exists:users,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $user = User::find($user_id);
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }
        return response()->json(['user' => $user]);
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            
            $user = Auth::user();
            if(!empty($user->verification_code) || !$user->verified){
                return response()->json(['message' => 'Incorrect login credentials.', 'error' => 'Incorrect login credentials.'], 400);
                // throw ValidationException::withMessages([
                //     'email' => ['The provided credentials are incorrect.'],
                // ]);
            }
            // $token = $user->createToken('access_token')->accessToken;
            $user = auth()->user();
            $user->api_token = Str::random(60);
            $user->device_type = $request->input('device_type', null);
            $user->device_id = $request->input('device_id', null);
            $user->device_token = $request->input('device_token', null);
            $user->save();

            return response()->json(['user' => $user]);
        } else {
            
        return response()->json(['message' => 'Incorrect login credentials.', 'error' => 'Incorrect login credentials.'], 400);
            // throw ValidationException::withMessages([
            //     'email' => ['The provided credentials are incorrect.'],
            // ]);
        }
        return response()->json(['message' => 'Incorrect login credentials.3333333333', 'error' => 'Incorrect login credentials.'], 400);
    }
    
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $api_token = Str::random(60);
        // Save the verification code to the user's record in the database
        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'password' => bcrypt($request->input('password')),
            'api_token' => $api_token,
            'verification_code' => null,
            'verified' => true,
        ]);
        
        $lati = $request->input('lati', null);//1=trainer, 2=client, 3=both
        $longi = $request->input('longi', null);//1=trainer, 2=client, 3=both
        
        if($lati) {
            $user['lati'] = $lati;
        }
        if($longi) {
            $user['longi'] = $longi;
        }

        $user = User::find($user['id']);

        
        return response()->json(['user' => $user]);

        // Generate a 6-digit verification code
        // $verificationCode = rand(100000, 999999);

        // // Save the verification code to the user's record in the database
        // $user = User::create([
        //     'name' => $request->input('name'),
        //     'email' => $request->input('email'),
        //     'password' => bcrypt($request->input('password')),
        //     // 'verification_code' => null,
        //     // 'verified' => true,
        //     'verification_code' => $verificationCode,
        //     'verified' => false,
        // ]);

        // // Send the verification code to the user via email
        // Mail::to($user->email)->send(new VerifyEmail($verificationCode));

        // $token = $user->createToken('access_token')->accessToken;

        // return response()->json(['access_token' => $token]);
    }
    public function updateUser(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'biography' => 'required|string',
            'user_id' => 'required|exists:users,id',
            'profile_image' => 'sometimes|mimes:jpeg,png,jpg,mp4,mp3',//|max:10000
            // 'first_name' => 'sometimes',
            // 'last_name' => 'sometimes',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        

        $user_id = $request->input('user_id', 0);
        $biography = $request->input('biography', '');
        $user_type = $request->input('user_type', null);//1=trainer, 2=client, 3=both
        $lati = $request->input('lati', null);//1=trainer, 2=client, 3=both
        $longi = $request->input('longi', null);//1=trainer, 2=client, 3=both
        $phone = $request->input('phone', null);//1=trainer, 2=client, 3=both
        $gender = $request->input('gender', null);//1=Male, 2=Female, 0=Not prefer to tell
        $user = User::find($user_id);
        // Save the verification code to the user's record in the database
        if($user) {
            $profile_data = [];
            if(!is_null($gender)) {
                $profile_data['gender'] = $gender;
            }
            if($biography) {
                $profile_data['biography'] = $biography;
            }
            if($lati) {
                $profile_data['lati'] = $lati;
            }
            if($longi) {
                $profile_data['longi'] = $longi;
            }
            if($phone) {
                $profile_data['phone'] = $phone;
            }
            if(isset($data['name'])) {
                $profile_data['name'] = $data['name'];
            }
            if(isset($data['device_type'])) {
                $profile_data['device_type'] = $data['device_type'];
            }
            if(isset($data['device_id'])) {
                $profile_data['device_id'] = $data['device_id'];
            }
            if(isset($data['device_token'])) {
                $profile_data['device_token'] = $data['device_token'];
            }
            if($user_type) {
                $profile_data['user_type'] = $user_type;
            }
            if(!empty($profile_data)) {
                $user->update($profile_data);
            }
        }
        else {
            return response()->json(['message' => 'Bad request', 'error' => 'Bad request, Please try again'], 400);
        }
        if($user) {
            if ($request->hasFile('profile_image')) {
                $image = $request->file('profile_image');
                // $size = $image->getSize();
                // list($width, $height) = getimagesize($image);
                // return [ $size, $width, $height ];
                $name = (string) Str::uuid() . '.' . $image->getClientOriginalExtension();

                $confirmUpload = $this->createThumbnail($image, $name);
                if($confirmUpload && file_exists($user->profile_image)) {
                    unlink($user->profile_image);
                }
                $file_path = 'img/' . $name;
                $user->update([
                    'profile_image' => $file_path
                ]);                

            //     $name = (string) Str::uuid() . '.' . $image->getClientOriginalExtension();

            //     $file_path =  'profile/' . $user_id . '/' . $name;
            //     $image = file_get_contents($image);
            //     $confirmUpload = false;
            //     if($image) {
            //         $confirmUpload = $this->putS3Image($file_path, $image, 'public');
            //     }
            //     // \Log::info(__LINE__ . ': ' . __FILE__  , [$file_path]);
    
            // $user->update([
            //     'profile_image' => $file_path
            // ]);

            //     if($confirmUpload && $user->profile_image) {
            //         Storage::disk('s3')->delete($user->profile_image);
            //     }
            }
        }
        $user = User::find($user_id);

        return response()->json(['user' => $user]);
        // return response()->json(['access_token' => $token, 'user' => $user]);

    }

    public function createThumbnail($source_file, $name) {
        // Specify the source image file
        // $source_file = 'path/to/image.jpg';

        // $path = Storage::putFile('avatars', $source_file);

        // Specify the destination thumbnail file
        $thumbnail_file = public_path('img' . DIRECTORY_SEPARATOR . $name);

        // Set the maximum dimensions for the thumbnail
        $max_width = 100;
        $max_height = 100;

        try {
            // Get the dimensions of the source image
            list($width, $height) = getimagesize($source_file);

            // Calculate the aspect ratio of the source image
            $aspect_ratio = $width / $height;

            // Calculate the dimensions of the thumbnail
            if ($aspect_ratio > 1) {
                $new_width = $max_width;
                $new_height = $max_height / $aspect_ratio;
            } else {
                $new_width = $max_width * $aspect_ratio;
                $new_height = $max_height;
            }

            // Create a new image resource for the thumbnail
            $thumbnail = imagecreatetruecolor($new_width, $new_height);

            // Load the source image
            $source_image = imagecreatefromjpeg($source_file);

            // Resize the source image to the dimensions of the thumbnail
            imagecopyresampled($thumbnail, $source_image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

            // Save the thumbnail as a JPEG image
            imagejpeg($thumbnail, $thumbnail_file, 70);

            // Free up memory by destroying the image resources
            imagedestroy($thumbnail);
            imagedestroy($source_image);
            return true;
        }
        catch(Exception $e) {
            return false;
        }
    }
    
        
    public function putS3Image($file_path, $image, $type) {
        $confirmUpload = Storage::disk('s3')->put($file_path, $image, $type);
        if ($confirmUpload)
            return true;
        else
            return false;
    }

    // Find or create a user based on the Social Auth details
    public function socialRegister(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'provider' => 'required|string',
            'provider_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $authUser = User::where(['provider_id' => $data['provider_id'], 'provider' => $data['provider']])->first();

        if ($authUser) {
            
            return response()->json(['user' => $authUser]);
        }
        
        $api_token = Str::random(60);

        $usr = User::create([
            'provider' => $data['provider'],
            'provider_id' => $data['provider_id'],
            'name' => $data['provider_id'],
            'email' => $data['provider'] .'_'. $data['provider_id'],
            'device_model' => $data['device_model'],
            'device_os' => $data['device_os'],
            'device_id' => $data['device_id'],
            'device_type' => $data['device_type'],
            'device_token' => $data['device_token'],
            'api_token' => $api_token,
            'password' => '',            
            'verification_code' => null,
            'verified' => true,
        ]);

        $user = User::find($usr['id']);

        
        return response()->json(['user' => $user]);
    }

    // Redirect the user to the Google authentication page
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    // Handle the Google authentication callback
    public function handleGoogleCallback()
    {
        try {
            // Get the user details from Google
            $user = Socialite::driver('google')->stateless()->user();

            // Check if the user already exists in the database
            $existingUser = User::where('email', $user->getEmail())->first();
            if ($existingUser) {
                Auth::login($existingUser);
                return redirect('/dashboard');
            }

            // If the user doesn't exist, create a new user
            $newUser = new User;
            $newUser->name = $user->getName();
            $newUser->email = $user->getEmail();
            $newUser->password = Hash::make(str_random(16)); // Generate a random password
            $newUser->save();

            Auth::login($newUser);
            return redirect('/dashboard');
        } catch (\Exception $e) {
            return redirect('/login');
        }
    }

    // Redirect the user to the Facebook authentication page
    public function redirectToFacebook()
    {
        return Socialite::driver('facebook')->redirect();
    }

    // Handle the Facebook authentication callback
    public function handleFacebookCallback()
    {
        try {
            // Get the user details from Facebook
            $user = Socialite::driver('facebook')->stateless()->user();

            // Check if the user already exists in the database
            $existingUser = User::where('email', $user->getEmail())->first();
            if ($existingUser) {
                Auth::login($existingUser);
                return redirect('/dashboard');
            }

            // If the user doesn't exist, create a new user
            $newUser = new User;
            $newUser->name = $user->getName();
            $newUser->email = $user->getEmail();
            $newUser->password = Hash::make(str_random(16)); // Generate a random password
            $newUser->save();

            Auth::login($newUser);
            return redirect('/dashboard');
        } catch (\Exception $e) {
            return redirect('/login');
        }
    }

    

}
