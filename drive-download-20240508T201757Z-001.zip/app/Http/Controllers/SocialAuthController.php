<?php

namespace App\Http\Controllers;

use App\Mail\VerifyEmail;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class SocialAuthController extends Controller
{
    
    
    // Redirect the user to the Google authentication page
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->stateless()->redirect();
    }

    // Handle the Google authentication callback
    public function handleGoogleCallback()
    {
        try {
            $user = Socialite::driver('google')->stateless()->user();
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to authenticate with Google'], 401);
        }

        $authUser = $this->findOrCreateUser($user, 'google');
        $token = $authUser->createToken('access_token')->accessToken;

        return response()->json(['access_token' => $token]);
    }

    // Redirect the user to the Facebook authentication page
    public function redirectToFacebook()
    {
        return Socialite::driver('facebook')->stateless()->redirect();
    }

    // Handle the Facebook authentication callback
    public function handleFacebookCallback()
    {
        try {
            $user = Socialite::driver('facebook')->stateless()->user();
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to authenticate with Facebook'], 401);
        }

        $authUser = $this->findOrCreateUser($user, 'facebook');
        $token = $authUser->createToken('access_token')->accessToken;

        return response()->json(['access_token' => $token]);
    }

    // Find or create a user based on the OAuth details
    public function findOrCreateUser($user, $provider)
    {
        $authUser = User::where('provider_id', $user->getId())->first();

        if ($authUser) {
            return $authUser;
        }

        return User::create([
            'name' => $user->getName(),
            'email' => $user->getEmail(),
            'password' => '',
            'provider' => $provider,
            'provider_id' => $user->getId(),
            
            'verification_code' => null,
            'verified' => true,
        ]);
    }
}

