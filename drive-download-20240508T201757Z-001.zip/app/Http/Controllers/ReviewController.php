<?php

namespace App\Http\Controllers;

use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReviewController extends Controller
{
    
    public function addReview(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'email' => 'required|email|exists:users',
        // ]);

        // if ($validator->fails()) {
        //     return response()->json(['error' => $validator->errors()], 401);
        // }

        $validator = Validator::make($request->all(), [
            'content' => 'required|string',
            'user_id' => 'required',//|id|exists:users
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        
        $user_id = $request->input('user_id', null);
        $content = $request->input('content', null);
        $rating = $request->input('rating', null);

        $item = [];
        $item['submitted_by'] = $user_id;
        $item['content'] = $content;
        $item['rating'] = $rating;
        // Save the review for the user's record in the database
        $review = Review::updateOrCreate(
            ['submitted_by' => $item['submitted_by']],
            $item
        );

        return response()->json(['message' => 'review successfully submitted', 'review' => $review]);
    }

    
    public function storeReview(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'email' => 'required|email|exists:users',
        // ]);

        // if ($validator->fails()) {
        //     return response()->json(['error' => $validator->errors()], 401);
        // }

        $validator = Validator::make($request->all(), [
            'content' => 'required|string',
            'user_id' => 'required',//|id|exists:users
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        
        $user_id = $request->input('user_id', null);
        $content = $request->input('content', null);
        $rating = $request->input('rating', null);

        $item = [];
        $item['submitted_by'] = $user_id;
        $item['content'] = $content;
        $item['rating'] = $rating;
        // Save the review for the user's record in the database
        $review = Review::updateOrCreate(
            ['submitted_by' => $item['submitted_by']],
            $item
        );

        return response()->json(['message' => 'review successfully submitted', 'review' => $review]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $sortBy = null;
        $orderBy = null;
        $filter = $request->get('filter', null);
        $pageSize = $request->get('pageSize', null);
        $user_id = $request->get('user_id', null);
        $sortByString = $request->get('sort', null)?:'id,desc:false';
        if ($sortByString){
            $sortByStringExp =  explode(',', $sortByString);
            $sortBy = $sortByStringExp[0];
            $orderByString = explode(':', $sortByStringExp[1]);
            $orderBy = $orderByString[1] == 'true' ? 'asc':'desc';
        }

        $reviews =  Review::with(['user'])
        ->when($user_id,function($q) use ($user_id){
            $q->where('submitted_by',$user_id);
        })
        ->when($filter,function($q) use ($filter){
            
            $q->where(function($q) use ($filter){
                $q->where('id','like', '%' . $filter . '%')
                    ->orWhere('content','like', '%' . $filter . '%')
                    ->orWhere('rating','like', '%' . $filter . '%')
                    // ->orWhereHas(['user' => function($q) use ($filter) {
                    //     $q->where('name','like', '%' . $filter . '%')
                    //     ->orWhere('email','like', '%' . $filter . '%')
                    //     ->first();
                    // }])
                    ;
            });
            
        })
        ->when($sortBy || $orderBy, function($query) use ($sortBy, $orderBy){
            $query->orderBy($sortBy, $orderBy);
        })
        ->paginate(20);

        $avgRating = Review::avg('rating');
        $count = Review::count();


        return response()->json(['reviews' => $reviews, 'avgRating' => $avgRating, 'count' => $count]);


        return $this->sendSuccessResponse('data', ['pagination' => $data], 'Templates retrieved successfully!');
    }

}
