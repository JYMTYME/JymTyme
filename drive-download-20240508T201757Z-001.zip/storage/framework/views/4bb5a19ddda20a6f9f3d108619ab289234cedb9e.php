Hello!

Your verification code is: <?php echo e($verificationCode); ?>


Please use this code to verify your email address.

Thank you,

<?php /**PATH D:\laragon\www\fitness\resources\views/emails/verifyemail.blade.php ENDPATH**/ ?>