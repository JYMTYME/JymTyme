Hello!

Your verification code is: {{ $verificationCode }}

Please use this code to verify your email address.

Thank you,

